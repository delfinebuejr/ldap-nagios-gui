package ModPerl::Util;

sub exit {};

1;
